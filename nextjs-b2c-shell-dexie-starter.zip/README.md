# Next.js + Azure AD B2C + Shell Adapter + Dexie (Starter)

A minimal starter that gives you:
- **Next.js (App Router)** front-end
- **Azure AD B2C** auth via **MSAL** (`@azure/msal-react`, `@azure/msal-browser`)
- **Shell Adapter**: swap between web and native shell implementations
- **Dexie** (IndexedDB) for offline caching
- **GitHub Actions** workflow for **Azure Static Web Apps** (SSR enabled)

## Quick start

```bash
# 1) Clone and install
npm i

# 2) Copy env
cp .env.local.example .env.local
# Fill in your B2C values

# 3) Run
npm run dev
```

Open http://localhost:3000

## Azure AD B2C config

- App Registration (SPA) -> clientId
- User flow name(s): `B2C_1_signupsignin`, `B2C_1_passwordreset` (or yours)
- Authority format:
  `https://<tenant>.b2clogin.com/<tenant>.onmicrosoft.com/<userflow>`
- Known authorities:
  `<tenant>.b2clogin.com`

## Deploy to Azure Static Web Apps

Create an SWA resource, capture its **deployment token** as
`AZURE_STATIC_WEB_APPS_API_TOKEN` repo secret, then push to `main` to trigger
the workflow in `.github/workflows/azure-static-web-apps.yml`.
