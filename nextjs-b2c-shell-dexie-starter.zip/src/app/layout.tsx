import './globals.css';
import React from 'react';
import AuthProvider from '@/components/AuthProvider';

export const metadata = {
  title: 'Next.js + B2C Starter',
  description: 'Starter with Azure AD B2C, Shell Adapter, Dexie'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <div className="container">
            <header style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
              <h1>Next.js + B2C + Shell + Dexie</h1>
              <nav style={{display:'flex', gap: 16}}>
                <a href="/">Home</a>
                <a href="/protected">Protected</a>
              </nav>
            </header>
            <main>{children}</main>
          </div>
        </AuthProvider>
      </body>
    </html>
  );
}
