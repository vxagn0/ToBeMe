'use client';
import React, { useEffect } from 'react';
import { useMsal } from '@azure/msal-react';
import { useRouter } from 'next/navigation';
import { SignOutButton } from '@/components/AuthButtons';

export default function ProtectedPage() {
  const { accounts } = useMsal();
  const router = useRouter();

  useEffect(() => {
    if (accounts.length === 0) router.replace('/');
  }, [accounts, router]);

  if (accounts.length === 0) return null;

  return (
    <section>
      <h2 className="text-xl font-semibold">Protected content</h2>
      <p className="mt-2">Only visible when signed in. Extend this page with your app features.</p>
      <div className="mt-4"><SignOutButton /></div>
    </section>
  );
}
