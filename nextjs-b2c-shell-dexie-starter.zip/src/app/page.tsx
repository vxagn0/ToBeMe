'use client';
import React from 'react';
import { useMsal } from '@azure/msal-react';
import { SignInButton, SignOutButton, AcquireTokenDemo } from '@/components/AuthButtons';
import DemoDexie from '@/components/DemoDexie';
import { Shell } from '@/lib/shell/IShell';

export default function HomePage() {
  const { accounts } = useMsal();
  const [device, setDevice] = React.useState<{platform: string; version: string} | null>(null);

  React.useEffect(() => {
    Shell().getDeviceInfo().then(setDevice).catch(console.error);
  }, []);

  return (
    <section>
      <p>This starter demonstrates a clean separation: Azure AD B2C auth, a pluggable Shell layer, and offline caching via Dexie.</p>
      <div className="mt-4" style={{display:'flex', gap:8}}>
        {accounts.length === 0 ? <SignInButton /> : <SignOutButton />}
      </div>
      {accounts.length > 0 && <AcquireTokenDemo />}

      <div className="mt-6">
        <h3 className="font-semibold">Signed in account</h3>
        <pre className="p-2 bg-gray-100">{accounts.length ? JSON.stringify(accounts[0], null, 2) : 'Not signed in'}</pre>
      </div>

      <div className="mt-6">
        <h3 className="font-semibold">Shell device info</h3>
        <pre className="p-2 bg-gray-100">{device ? JSON.stringify(device, null, 2) : 'Loading...'}</pre>
      </div>

      <DemoDexie />
    </section>
  );
}
