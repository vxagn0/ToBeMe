import Dexie, { Table } from 'dexie';

export interface Item {
  id?: number;
  key: string;
  value: string;
  createdAt: number;
}

export class AppDB extends Dexie {
  items!: Table<Item, number>;
  constructor() {
    super('appdb');
    this.version(1).stores({
      items: '++id, key, createdAt'
    });
  }
}

export const db = new AppDB();
