export const webShell = {
  async getDeviceInfo() {
    return { platform: 'web' as const, version: navigator.userAgent };
  },
  async registerForPush(_topic?: string) {
    // Web Push wiring to be added later; return empty token for now
    return {};
  },
  async share(payload: { title: string; text?: string; url?: string }) {
    if ((navigator as any).share) {
      await (navigator as any).share(payload);
    }
  },
  async pickMedia() {
    return undefined; // Use <input type="file"> in UI instead
  },
  async openDeepLink(url: string) {
    window.location.href = url;
  }
};
