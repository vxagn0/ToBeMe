// Stub for a future native shell (Capacitor/React Native)
export const nativeShell = {
  async getDeviceInfo() {
    return { platform: 'android' as const, version: '1.0.0' };
  },
  async registerForPush(_topic?: string) {
    // Wire to FCM/APNs via native layer & Azure Notification Hubs
    return { token: undefined };
  },
  async share(_payload: { title: string; text?: string; url?: string }) {
    // Native share
  },
  async pickMedia() {
    // Native picker -> Blob
    return undefined;
  },
  async openDeepLink(_url: string) {
    // Native deep link
  }
};
