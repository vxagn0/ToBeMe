export type Platform = 'web' | 'ios' | 'android';

export interface IShell {
  getDeviceInfo(): Promise<{ platform: Platform; version: string }>;
  registerForPush(topic?: string): Promise<{ token?: string }>;
  share(payload: { title: string; text?: string; url?: string }): Promise<void>;
  pickMedia(options?: { video?: boolean }): Promise<File | Blob | undefined>;
  openDeepLink(url: string): Promise<void>;
}

// Runtime-selected shell
declare global {
  var __NATIVE__: boolean | undefined;
}

let impl: IShell | undefined;
export function setShell(shell: IShell) {
  impl = shell;
}
export function Shell(): IShell {
  if (!impl) throw new Error('Shell not initialised');
  return impl;
}
