'use client';
import { PublicClientApplication, Configuration, LogLevel } from '@azure/msal-browser';

const getEnv = (k: string, fallback?: string) => {
  const v = process.env[k] || (globalThis as any).process?.env?.[k];
  if (v) return String(v);
  if (fallback !== undefined) return fallback;
  throw new Error(`Missing env: ${k}`);
};

const clientId = getEnv('NEXT_PUBLIC_B2C_CLIENT_ID');
const authority = getEnv('NEXT_PUBLIC_B2C_AUTHORITY');
const knownAuthorities = getEnv('NEXT_PUBLIC_B2C_KNOWN_AUTHORITIES');
const redirectUri = getEnv('NEXT_PUBLIC_B2C_REDIRECT_URI', 'http://localhost:3000');
const postLogoutRedirectUri = getEnv('NEXT_PUBLIC_B2C_POST_LOGOUT_REDIRECT_URI', 'http://localhost:3000');

export const msalConfig: Configuration = {
  auth: {
    clientId,
    authority,
    knownAuthorities: [knownAuthorities],
    redirectUri,
    postLogoutRedirectUri
  },
  cache: {
    cacheLocation: 'localStorage',
    storeAuthStateInCookie: false
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) return;
        if (level === LogLevel.Error) console.error(message);
        if (level === LogLevel.Warning) console.warn(message);
        if (level === LogLevel.Info) console.info(message);
        if (level === LogLevel.Verbose) console.debug(message);
      }
    }
  }
};

export const msalInstance = new PublicClientApplication(msalConfig);

export const defaultScopes = (process.env.NEXT_PUBLIC_B2C_SCOPES ?? 'openid,offline_access')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);
