'use client';
import React, { useEffect } from 'react';
import { MsalProvider } from '@azure/msal-react';
import { msalInstance, defaultScopes } from '@/lib/msalConfig';
import { setShell } from '@/lib/shell/IShell';
import { webShell } from '@/lib/shell/webShell';

export default function AuthProvider({ children }: { children: React.ReactNode }) {
  // Default to web shell; a native wrapper can call setShell(nativeShell) earlier
  useEffect(() => {
    setShell(webShell);
  }, []);

  // Preload accounts so hooks work immediately
  useEffect(() => {
    msalInstance.handleRedirectPromise().catch(console.error);
  }, []);

  return <MsalProvider instance={msalInstance}>{children}</MsalProvider>;
}
