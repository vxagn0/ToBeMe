'use client';
import React from 'react';
import { db } from '@/lib/db';

export default function DemoDexie() {
  const [items, setItems] = React.useState<{id?: number, key: string, value: string, createdAt: number}[]>([]);
  const [key, setKey] = React.useState('sample');
  const [value, setValue] = React.useState('Hello, offline world!');

  const refresh = async () => {
    const rows = await db.items.orderBy('createdAt').reverse().toArray();
    setItems(rows);
  };

  React.useEffect(() => { refresh(); }, []);

  const add = async () => {
    await db.items.add({ key, value, createdAt: Date.now() });
    await refresh();
  };

  const clear = async () => {
    await db.items.clear();
    await refresh();
  };

  return (
    <div className="mt-6 border rounded p-4">
      <h3 className="font-semibold">Dexie demo (IndexedDB)</h3>
      <div className="mt-2 flex gap-2">
        <input className="border p-2 rounded" value={key} onChange={e => setKey(e.target.value)} placeholder="key" />
        <input className="border p-2 rounded" value={value} onChange={e => setValue(e.target.value)} placeholder="value" />
        <button className="px-3 py-2 rounded bg-green-600 text-white" onClick={add}>Add</button>
        <button className="px-3 py-2 rounded bg-gray-200" onClick={clear}>Clear</button>
      </div>
      <ul className="mt-3 list-disc pl-6">
        {items.map(i => <li key={i.id}><code>{i.key}</code>: {i.value} <small>({new Date(i.createdAt).toLocaleString()})</small></li>)}
      </ul>
    </div>
  );
}
