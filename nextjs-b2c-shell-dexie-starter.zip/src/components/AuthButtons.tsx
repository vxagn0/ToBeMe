'use client';
import React from 'react';
import { useMsal } from '@azure/msal-react';
import { InteractionRequiredAuthError, PopupRequest, RedirectRequest } from '@azure/msal-browser';
import { defaultScopes } from '@/lib/msalConfig';

const loginRequest: PopupRequest = { scopes: defaultScopes };
const redirectRequest: RedirectRequest = { scopes: defaultScopes };

export function SignInButton() {
  const { instance } = useMsal();
  return (
    <button
      onClick={() => instance.loginPopup(loginRequest).catch(() => instance.loginRedirect(redirectRequest))}
      className="px-3 py-2 rounded bg-black text-white"
    >
      Sign in
    </button>
  );
}

export function SignOutButton() {
  const { instance, accounts } = useMsal();
  return (
    <button
      onClick={() => instance.logoutPopup({ account: accounts[0] }).catch(() => instance.logoutRedirect())}
      className="px-3 py-2 rounded bg-gray-200"
    >
      Sign out
    </button>
  );
}

export function AcquireTokenDemo() {
  const { instance, accounts } = useMsal();
  const [token, setToken] = React.useState<string>('');

  const acquire = async () => {
    const request = { scopes: defaultScopes, account: accounts[0] };
    try {
      const res = await instance.acquireTokenSilent(request);
      setToken(res.accessToken);
    } catch (e) {
      if (e instanceof InteractionRequiredAuthError) {
        const res = await instance.acquireTokenPopup(request);
        setToken(res.accessToken);
      } else {
        throw e;
      }
    }
  };

  return (
    <div className="mt-4">
      <button onClick={acquire} className="px-3 py-2 rounded bg-blue-600 text-white">Get Access Token</button>
      {token && <pre className="mt-2 p-2 bg-gray-100 break-all">{token}</pre>}
    </div>
  );
}
